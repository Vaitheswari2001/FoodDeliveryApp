import { Invoice } from './invoice';

describe('Invoice', () => {
  it('should create an instance', () => {
    expect(new Invoice()).toBeTruthy();
  });
});
