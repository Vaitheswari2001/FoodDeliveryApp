export class DummyPayment {
    public static  personName:string="Akhil";
    public static cardNum:string = " 1234567890123456";
    public static expiryDate:string = "09/2023";
    public static cvv:any="123";
}
